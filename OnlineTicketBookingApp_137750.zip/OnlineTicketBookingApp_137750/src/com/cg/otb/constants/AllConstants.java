package com.cg.otb.constants;

public class AllConstants {
	
	public static final String showDetailsCommand="select * from showdetails";
	public static final String getShowDetailCommand="select * from showdetails where showid=?";
	public static final String updateShowCommand="update showdetails set avseats = ? where showname = ?";

}
